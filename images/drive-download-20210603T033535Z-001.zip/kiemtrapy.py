import numpy as np
import pandas as pd 
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
#3a
df = pd.read_csv ('face.csv')
print(df)
f_list=[]
for i in range(128):
    sz='EMB_'+str(i+1)
    f_list.append(sz)
X=df[f_list]
print(X) 

#3b
print('Kmeans')
phan_cum = KMeans(n_clusters=79, random_state=0).fit(X)
centers = phan_cum.cluster_centers_
print (centers)

#3c
plt.scatter(df['EMB_6'], df['EMB_7'], c= phan_cum.labels_.astype(float),alpha=0.5)
plt.scatter(centers[:, 0], centers[:, 1], c='red')
plt.show()

#3d
mau_moi=np.array([0.32714815,-0.22074495,-0.043450274,-0.13720256,-0.07745706,-0.10667298,0.004801472,-0.026113743,-0.104959816,0.07916366,0.037622776,-0.025126016,0.013541422,-0.07517471,0.07620214,-0.00032201802,0.07851215,-0.07611115,0.07065341,0.06726032,-0.105666585,0.02971501,-0.176883,0.09826957,0.04701207,0.01790167,0.046678875,-0.032449372,0.0869289,-0.09421948,0.06706382,0.02383662,-0.0015956922,-0.18975537,0.009891883,0.011035533,-0.30791361,0.10467171,0.13095011,0.07539504,0.082864076,0.049527958,0.12580529,-0.06761194,-0.06632462,-0.16151021,0.0058762566,0.09525009,-0.056547698,-0.007982472,-0.048915192,0.08933437,0.057254523,-0.0967138,0.033779994,-0.097341426,0.096009925,0.14670342,0.023388451,-0.034732066,0.048809655,-0.15241314,-0.09554148,0.2066808,0.1262436,0.12066179,0.14310437,0.027598206,0.028077202,0.005030728,-0.13347289,-0.13956502,0.021395933,-0.10557232,-0.002604257,-0.044238213,-0.06690789,-0.014660075,-0.09556474,-0.07075569,-0.044118453,0.008914337,-0.0107516805,-0.030390555,0.082991116,-0.14888825,-0.06608179,-0.057988454,-0.17154412,0.08281842,0.11609265,-0.037194397,-0.010196879,-0.011433893,0.016719729,-0.083021045,-0.0180706,0.08509958,-0.096570455,-0.022777043,-0.04252939,0.008879919,0.1400144,0.054218855,-0.04977526,0.015690932,0.0976066,0.055143848,-0.029953556,-0.07694861,0.02645639,0.1507644,0.16923787,-0.034205783,-0.018500559,-0.11458846,-0.011977786,0.14909431,0.17248285,0.07561229,0.072965965,0.0239089,-0.020423647,0.0090930825,0.10653353,-0.16300812,-0.06417947,0.02185152])
mau_moi=mau_moi.reshape(1,128)#mảng 1 dòng 128 cột
kq=phan_cum.predict(mau_moi)
print('Thuoc cum:',kq[0])
plt.scatter(df['EMB_6'], df['EMB_7'], c= phan_cum.labels_.astype(float),alpha=0.5)
plt.scatter(centers[:, 0], centers[:, 1], c='red')
plt.scatter(mau_moi[0,0], mau_moi[0,1], c= kq[0],marker="x")
plt.show()

#3e
print(phan_cum.inertia_)
list_do_lech=[]
for C in range (79):
    phan_cum = KMeans(n_clusters=C, random_state=0).fit(df[['EMB_6','EMB_7']])
    do_lech=phan_cum.inertia_
    list_do_lech.append(do_lech)
print(list_do_lech)

#3g
print(phan_cum.inertia_)
list_do_lech=[]
for C in range (70,90+1):
    phan_cum = KMeans(n_clusters=C, random_state=0).fit(df[['EMB_6','EMB_7']])
    do_lech=phan_cum.inertia_
    list_do_lech.append(do_lech)
print(list_do_lech)