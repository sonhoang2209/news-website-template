import  cv2
import  numpy as np

I=cv2.imread('Lena.jpg')
cv2.imshow('anh goc',I)

# anh hsv
Ihsv=cv2.cvtColor(I,cv2.COLOR_BGR2HSV)
cv2.imshow('anh Ihsv',Ihsv)

# kenh V cua Ihsv

cv2.imshow('kenh V anh Ihsv',Ihsv[:,:,2])

# muc sanh lon nhat cua kenh V cua Ihsv
print('Độ sáng  max của kênh V')
print(np.max(Ihsv[:,:,2]))

#lam tron anh tren kenh s cua Ihsv
Is=cv2.blur(Ihsv[:,:,1],(5,5))
cv2.imshow('Is',Is)


# nhị phan hoa nghich dao
thresh, Ib = cv2.threshold(255 - Is, 0, 255, cv2.THRESH_OTSU)
cv2.imshow("Ib", Ib)

 #Tìm các contour co dien tich lon nhat  của ảnh Ib. Vẽ các đường contour trên ảnh gốc I. Hiển thị ảnh I.'''


contours, _ = cv2.findContours(Ib, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
cv2.drawContours(I, contours, -1, (0, 0, 255), 2)
cv2.imshow("Anh sau khi ve lan 1", I)



max1 = 0.0
contours_max1 = []
for contour in contours:
    if cv2.contourArea(contour) > max1:
        max1=cv2.contourArea(contour)
        contours_max1 = contour

cv2.drawContours(I, [contours_max1], -1, (0,255,0), 2)
cv2.imshow("Anh sau khi ve lan 2 cach 2", I)


cv2.waitKey()