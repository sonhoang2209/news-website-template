
import cv2
import sys
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.image as mpimg
# đọc ảnh 1.jpg
img = cv2.imread("Lena.png")
#câu 2 chuyển ảnh sang hệ hsv
hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
(hsv_h, hsv_s, hsv_v) = cv2.split(hsv)
print("mức xám lớn nhất của ảnh là",np.max(hsv_v))
#3 làm trơn kênh s 
IsImg = cv2.medianBlur(hsv_s, 5)
#4 nhị phân hóa ảnh
ret, bw_img = cv2.threshold(hsv_s, 127, 255, cv2.THRESH_OTSU)
bw = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
#5 xác định đường contour lớn nhất
img1 = img.copy()
contours, hierarchy = cv2.findContours(bw_img, cv2.RETR_EXTERNAL,
cv2.CHAIN_APPROX_NONE)
cv2.drawContours(img1, contours, -1, 255, 3)
#câu 6
def change_brightness(img, alpha, beta):
    img_new = np.asarray(alpha*img + beta, dtype=int)   # cast pixel values to int
    img_new[img_new>255] = 255
    img_new[img_new<0] = 0
    return img_new
alpha = 1.0
beta = 35
if len(sys.argv) == 3:
    alpha = float(sys.argv[1])
    beta = int(sys.argv[2])
hsv_vNew = change_brightness(hsv_v, alpha, beta)
hsv[:,:,2] = hsv_vNew
rgb = cv2.cvtColor(hsv,cv2.COLOR_BGR2RGB)
cv2.imwrite("img_3_new.jpg",rgb)
#kết quả
cv2.imshow("cau1",img)
cv2.imshow("cau2",hsv_v)
cv2.imshow("cau 3",IsImg)
cv2.imshow("cau 4",bw_img)
cv2.imshow("cau 5",img1)
imgs = cv2.imread("img_3_new.jpg")
cv2.imshow("cau 6",rgb)
cv2.waitKey(0)